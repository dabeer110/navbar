class car {
    // properties
    carname
    model
    color

    constructor(name,model,color){
        this.name= name;
        this.model= model;
        this.color= color

    }
}
let obj1= new car("supra",2024,"black") 
let obj2= new car("civic",2024,"black")
console.log(obj1.name) 